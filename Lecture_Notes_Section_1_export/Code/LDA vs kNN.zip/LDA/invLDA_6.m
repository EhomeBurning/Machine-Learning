close all
load fisheriris
X = meas(:,[1 3]);
X(:,2) = X(:,2)*4;
y = categorical(species);
labels = categories(y);

figure
gscatter(X(:,1),X(:,2),species,'rgb','osd');
axis equal
%xlabel('Sepal length');
%ylabel('Sepal width');
figure
XT = X*(X'*X/150)^(-1/2);

gscatter(XT(:,1),XT(:,2),species,'rgb','osd');
axis equal

%xlabel('Sepal length');
%ylabel('Sepal width');
