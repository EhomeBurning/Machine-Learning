clear all
close all
load fisheriris
gscatter(meas(:,1), meas(:,2), species,'rgb','osd');
xlabel('Sepal length','fontsize',18);
ylabel('Sepal width','fontsize',18);
N = size(meas,1);
rng(1)
lda = fitcdiscr(meas(:,1:2),species,'DiscrimType','quadratic');
ldaClass = resubPredict(lda);

trainingErr = resubLoss(lda)
[confusionMatrix,grpOrder] = confusionmat(species,ldaClass);
%%

% bad = ~strcmp(ldaClass,species);
% hold on;
% plot(meas(bad,1), meas(bad,2), 'kx');
% hold off;



