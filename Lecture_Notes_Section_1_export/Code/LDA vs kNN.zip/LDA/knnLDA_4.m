load fisheriris
X = meas;
Y = species;
%
rng(1); % For reproducibility
Mdl = fitcknn(X,Y,'NumNeighbors',5);
TrainLosskNN = resubLoss(Mdl)
CVMdl = crossval(Mdl,'KFold',10);
CVLosskNN = kfoldLoss(CVMdl)
