clear all
load ovariancancer
obj = fitcdiscr(obs,grp,...
    'SaveMemory','on','FillCoeffs','off');
%gscatter(obs(:,1),obs(:,2),grp)
%
[~,~,id] = unique(grp);
colors = 'rgb';
markers = 'osd';
for idx = 1 : 2
    data = obs(id == idx,:);
    plot3(data(:,1), data(:,2), data(:,3), [colors(idx) markers(idx)]);
    hold on;
end
grid
legend('cancer','normal')
size(obs)
drawnow
%%
rng('default') % for reproducibility
[err,gamma] = cvshrink(obj,...
    'Gamma',0.5:0.1:1,'Verbose',1);
figure
plot(gamma,err,'r','linewidth',2);
grid;
title('LDA','fontsize',16')
legend('cross validation error','training error')
xlabel('gamma','fontsize',16)
ylabel('CV error','fontsize',16)
%%

figure
kvalues =1:2:19;
for k=kvalues
Mdl = fitcknn(obs,grp,'NumNeighbors',k);
TrainLosskNN(k) = resubLoss(Mdl)
CVMdl = crossval(Mdl,'KFold',10);
CVLosskNN(k) = kfoldLoss(CVMdl)
plot((1:2:k),CVLosskNN(1:2:k),'r','linewidth',2);
hold on;
plot((1:2:k),TrainLosskNN(1:2:k),'k','linewidth',2);
legend('cross validation error','training error')
title('kNN','fontsize',16')
xlabel('k','fontsize',16)
ylabel('CV error and training error','fontsize',16)
drawnow
grid
end