load fisheriris
X = meas(:,1:2);
y = categorical(species);
labels = categories(y);

%
rng(1); % For reproducibility
classifier_name = {'LDA','QDA','Nearest Neighbor','5-NN'};

classifier{1} = fitcdiscr(X,y);
classifier{2} = fitcdiscr(X,y,'DiscrimType','quadratic');
classifier{3} = fitcknn(X,y);
classifier{4} = fitcknn(X,y,'NumNeighbors',5);

x1range = min(X(:,1)):.01:max(X(:,1));
x2range = min(X(:,2)):.01:max(X(:,2));
[xx1, xx2] = meshgrid(x1range,x2range);
XGrid = [xx1(:) xx2(:)];

%%
for i = 1:numel(classifier)
   predictedspecies = predict(classifier{i},XGrid);

   subplot(2,2,i);
  
   gscatter(xx1(:), xx2(:), predictedspecies,'rgb');

   title(classifier_name{i})
   legend off, axis tight
end
subplot(2,2,1)
xlabel('LDA trainerror=0.2 CVerror=0.2','fontsize',16)
subplot(2,2,2)
xlabel('QDA trainerror=0.18 CVerror=0.24','fontsize',16)
subplot(2,2,3)
xlabel('1-NN trainerror=0 CVerror=0.040','fontsize',16)
subplot(2,2,4)
xlabel('5-NN trainerror=0.033 CVerror=0.033','fontsize',16)
%legend(labels,'Location',[0.35,0.01,0.35,0.05],'Orientation','Horizontal')