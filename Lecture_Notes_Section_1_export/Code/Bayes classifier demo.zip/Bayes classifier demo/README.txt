
Login to Twitter, create an application and get access tokens from Twitter
(See details in https://www.slickremix.com/docs/how-to-get-api-keys-and-tokens-for-twitter/)

Modify getTweetVectors.m using your access tokens( ConsumerKey,ConsumerSecret,AccessToken,AccessTokenSecret)

Run runTwitterBayes.m for Bayes Classifier demo

Run runTwitter.m for inner-product demo

Run runTwitterLarger.m for SVD visualization demo