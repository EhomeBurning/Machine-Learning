function [ v, dict, n] = getTweetVectors( usernames,count)
% a sample structure array to store the credentials

%%% MODIFY below with your access tokens
creds = struct('ConsumerKey','',...
    'ConsumerSecret','',...
    'AccessToken','',...
    'AccessTokenSecret','');


stopwordsURL ='http://www.textfixer.com/resources/common-english-words.txt';
%count = 100;
% set up a Twitty object
%addpath twitty_1.1.1; % Twitty
%addpath parse_json; % Twitty's default json parser
addpath jsonlab-1.5; % I prefer JSONlab, however.
%load('creds.mat') % load my real credentials
tw = twitty(creds); % instantiate a Twitty object
tw.jsonParser = @loadjson; % specify JSONlab as json parser

% search for English tweets that mention 'amazon' and 'hachette'
%%amazon = tw.search('amazon','count',100,'include_entities','true','lang','en');
%hachette = tw.search('hachette','count',100,'include_entities','true','lang','en');
%both = tw.search('amazon hachette','count',100,'include_entities','true','lang','en');

%amazon{1,1}.statuses{1,1}.text

% [amazonUsers,amazonTweets] = processTweets.extract(amazon);
% stopwordsURL ='http://www.textfixer.com/resources/common-english-words.txt';
% 
% [words, dict] = processTweets.tokenize(amazonTweets,stopwordsURL);
% % create a dictionary of unique words
% dict = unique(dict);
% % create a word count matrix
% [~,tdf] = processTweets.getTFIDF(words,dict);
% 

%Zucker = tw.userTimeline('screen_name', 'finkd','count',1000);
T=[];
for userid = 1:length(usernames)
disp(['Processing: ' num2str(userid)])
userData = tw.userTimeline('screen_name', usernames{userid},'count',count);
[~,Tweets] = processTweets.extract(userData);
Tweets.Mentions=[];
Tweets.Hashtags=[];
T = [T;Tweets];
userSize(userid) = size(Tweets,1);
end
userSizeC = cumsum([0,userSize]);

[words, dict] = processTweets.tokenize(T,stopwordsURL);

dict = unique(dict);
[~,tdf] = processTweets.getTFIDF(words,dict);
for userid = 1:length(usernames)
v(:,userid) = ( sum(tdf(1+userSizeC(userid):userSizeC(userid+1),:)) )';
%v(:,userid) = v(:,userid)>0; %Binary counts
%v(:,userid) = v(:,userid)/norm(v(:,userid));
end

