% a sample structure array to store the credentials
creds = struct('ConsumerKey','55jEXjHQf869F42eMBzP8V3EO',...
    'ConsumerSecret','XuhIB3dQ3S0cPavgNIJwHpaCSZITe6N7k8ZwD56hEKrjGsnCZ9',...
    'AccessToken','906358792576741376-RAXGrkvDCfUUXifQvZFlQHLQ9SxyJjB',...
    'AccessTokenSecret','kdCMXQYU6ECYCVihyVW6x2QIkZoZTHnH2EfHNodzuRoVZ');
stopwordsURL ='http://www.textfixer.com/resources/common-english-words.txt';
count = 100;
% set up a Twitty object
addpath twitty_1.1.1; % Twitty
%addpath parse_json; % Twitty's default json parser
addpath jsonlab-1.5; % I prefer JSONlab, however.
%load('creds.mat') % load my real credentials
tw = twitty(creds); % instantiate a Twitty object
tw.jsonParser = @loadjson; % specify JSONlab as json parser

% search for English tweets that mention 'amazon' and 'hachette'
%%amazon = tw.search('amazon','count',100,'include_entities','true','lang','en');
%hachette = tw.search('hachette','count',100,'include_entities','true','lang','en');
%both = tw.search('amazon hachette','count',100,'include_entities','true','lang','en');

%amazon{1,1}.statuses{1,1}.text

% [amazonUsers,amazonTweets] = processTweets.extract(amazon);
% stopwordsURL ='http://www.textfixer.com/resources/common-english-words.txt';
% 
% [words, dict] = processTweets.tokenize(amazonTweets,stopwordsURL);
% % create a dictionary of unique words
% dict = unique(dict);
% % create a word count matrix
% [~,tdf] = processTweets.getTFIDF(words,dict);
% 

%Zucker = tw.userTimeline('screen_name', 'finkd','count',1000);
Katy = tw.userTimeline('screen_name', 'katyperry','count',count);
Musk = tw.userTimeline('screen_name', 'elonmusk','count',count);
Trump = tw.userTimeline('screen_name', 'realDonaldTrump','count',count);
Obama = tw.userTimeline('screen_name', 'BarackObama','count',count);

[~,Tweets1] = processTweets.extract(Katy);
[~,Tweets2] = processTweets.extract(Musk);
[~,Tweets3] = processTweets.extract(Trump);
[~,Tweets4] = processTweets.extract(Obama);
Tweets1.Mentions=[];
Tweets2.Mentions=[];
Tweets3.Mentions=[];
Tweets4.Mentions=[];
Tweets1.Hashtags=[];
Tweets2.Hashtags=[];
Tweets3.Hashtags=[];
Tweets4.Hashtags=[];

T = [Tweets1;Tweets2;Tweets3;Tweets4];
s1 = size(Tweets1,1);
s2 = size(Tweets2,1);
s3 = size(Tweets3,1);


[words, dict] = processTweets.tokenize(T,stopwordsURL);

dict = unique(dict);
[~,tdf] = processTweets.getTFIDF(words,dict);
v1 = sum(tdf(1:s1,:));
v2 = sum(tdf(s1+1:s1+s2,:));
v3 = sum(tdf(s1+s2+1:s1+s2+s3,:));
v4 = sum(tdf(s1+s2+s3+1:end,:));


v1 = v1'/norm(v1);
v2 = v2'/norm(v2);
v3 = v3'/norm(v3);
v4 = v4'/norm(v4);