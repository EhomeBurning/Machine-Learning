%clear all
close all
userList = {'realDonaldTrump','elonmusk'}; %'HillaryClinton',
%[W,dict] = getTweetVectors(userList,200); % uncomment to get fresh data
%from Twitter
load dataBayes
%%
v1 = W(:,1);
n1 = sum(v1);
p1 = v1/n1;

v2 = W(:,2);
n2 = sum(v2);
p2 = v2/n2;
%%
plot(p1,'r')
title('@realDonaldTrump','fontsize',20)
hold on
for i=1:size(W,1)
    text(i,p1(i),['\leftarrow' dict{i}],'fontsize',18)
end
figure
plot(p2)
title('@elonmusk','fontsize',20)
hold on
for i=1:size(W,1)
    text(i,p2(i),['\leftarrow' dict{i}],'fontsize',18)
end

%% dict(1169) = mexico
format long
wordId = 1168;
probTrump = p1(wordId)*n1/(n1+n2);
probMusk = p2(wordId)*n2/(n1+n2);
%%
sprintf('P(Trump|mexico) ~ %.8f,\nP(Musk|mexico) ~ %.8f', probTrump, probMusk)

