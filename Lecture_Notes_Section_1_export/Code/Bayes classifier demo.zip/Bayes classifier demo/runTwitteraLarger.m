%% Singular Value Decomposition 
%% terms x user matrix
clear all
n = 100;
%load accounts200
%userList = accounts(1:n); % popular 100 users
%[W,dict] = getTweetVectors(userList,200); % return 200 tweets
load Wdict
%%
[U,S,V] = svd(W,'econ');
hold on
for i=1:n
    plot(V(i,1),V(i,2),'o')
    text(V(i,1),V(i,2),['\leftarrow' accounts{i}])
    %text(U(1,i),U(2,i),num2str(i))
end