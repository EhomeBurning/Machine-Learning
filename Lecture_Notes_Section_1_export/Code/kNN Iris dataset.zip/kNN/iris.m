load fisheriris
X = meas;
Y = species;
gscatter(X(:,1),X(:,3),Y)
xlabel('sepal length','fontsize',18)
ylabel('petal length','fontsize',18)
grid
%%
rng(10); % For reproducibility
Mdl = fitcknn(X,Y,'NumNeighbors',4);
kvalues = 1:2:39
for kval = kvalues
Mdl = fitcknn(X,Y,'NumNeighbors',kval);
TrainLoss(kval) = resubLoss(Mdl);
CVMdl = crossval(Mdl,'KFold',10);
CVLoss(kval) = kfoldLoss(CVMdl);
disp(kval)
end
%
figure
plot(kvalues,CVLoss(kvalues),'r','linewidth',2);
hold on;
plot(kvalues,TrainLoss(kvalues),'k','linewidth',2);
grid
legend('cross validation error','training error')