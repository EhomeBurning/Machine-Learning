clear all
userList = {'realDonaldTrump','HillaryClinton','elonmusk'}
[W,dict] = getTweetVectors(userList,200);
%%
clear topWords
for user=1:3
    [~,order]=sort(W(:,user),'descend');
    topWords(:,user) = dict(order(1:10));
end
topWords
%%
v1 = W(:,1);
v2 = W(:,2);
v3 = W(:,3);
C = W'*W;
v1'*v2
v1'*v3
v2'*v3
